#include <stdio.h>

int ex1(int a, int b, int c, int d) {
    return 2*a + b + 3 * c + 6*d;
}

int main() {
    printf("%d\n", ex1(3, 4, 10, 2));
    return 0;
}
