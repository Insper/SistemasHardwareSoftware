int soma_2n(unsigned int n) {
    int count_bin_digits = 1;
    while (n > 1) {
        n = n / 2;
        count_bin_digits++;
    }
    return count_bin_digits;
}
