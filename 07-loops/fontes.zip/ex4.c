#include <stdio.h>

long ex4(long n, long dig) {
    long soma = 0;
    for (long i = 0; i < n; i++) {
        if (i % dig == 0) {
         soma += i;
        }
    }
    return soma;
}

int main() {
    printf("%d\n", ex4(100, 4));
    return 0;
}
