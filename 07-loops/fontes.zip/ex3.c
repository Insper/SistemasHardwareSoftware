#include <stdio.h>

int exemplo2(int d) {
    int n, i ;
    scanf("%d %d", &n, &i);
    i = i * 2;
    n = n + i;
    
    return d + n;
}

int main() {
    printf("%d\n", exemplo2(20));
}
