long soma_n(int n) {
    long soma = 0;
    for(int i = 0; i < n; i++) {
        soma += i;
    }
    return soma;
}
