#include <stdio.h>

int ex2(int a, int b, int *c) {
    if (a > b) {
        *c = a;
        return 1;
    } 
    *c = b;
    return 0;
}

int main() {
    int mm;
    int res = ex2(10, 2, &mm);
    printf("%d %d\n", res, mm);
    return 0;
}
