int exemplo1(int a, int b, int c, int d, int e, int f) {
    return a+b+c+d+e+f;
}

int main() {
    int c = exemplo1(1, 2, 3, 4, 5, 6) + 10;
    printf("%ld\n", c);
}
