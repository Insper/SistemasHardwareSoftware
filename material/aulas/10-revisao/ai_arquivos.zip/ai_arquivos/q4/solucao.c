// Questao 04
// Implemente aqui uma funcao chamada ex4_solucao

