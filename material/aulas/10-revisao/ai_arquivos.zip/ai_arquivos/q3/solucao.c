// Questao 03
// Implemente aqui uma funcao chamada ex3_solucao
