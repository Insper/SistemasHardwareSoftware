// Leia o README para mais infos sobre a q3!

// Implemente aqui uma funcao chamada ex4_solucao