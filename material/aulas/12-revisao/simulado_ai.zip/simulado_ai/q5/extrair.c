// Faça seus includes aqui!
#include <stdio.h>
#include <stdlib.h>

char *extrair_arquivo(char *url) {
    // SUA SOLUCAO AQUI!
    return NULL; // Você vai precisar alterar este return!
}
