#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);
    
    if (n < 0) {
        printf("Negativo\n");
    } else {
        printf("Positivo!\n");
    }
    return 0;
}
