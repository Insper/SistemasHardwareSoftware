Este exercício é corrigido automaticamente pelo arquivo `corretor.py`. Para usá-lo siga as instruções abaixo:

1. O corretor automático depende do pacote `grading-tools`, que deverá ser instalado como abaixo.

```shell
$> python3.8 -m pip install --user git+https://github.com/igordsm/grading-tools
```

2. Após instalar, compile seu programa.
3. Execute `python3.8 corretor.py ./seu_programa`.

