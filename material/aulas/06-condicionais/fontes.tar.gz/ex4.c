int fun4(long a, long b) {
    long c = 1;
    if (a > 0) {
        c = 2;
    }
    c *= b;
    return c;
}
