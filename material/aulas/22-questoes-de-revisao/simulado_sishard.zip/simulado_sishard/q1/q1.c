// Leia o PDF ou MD antes de iniciar este exercício!


// Faça os includes necessários aqui
// #include ...

void *thread1(void *_arg) {

    printf("A\n");

    
    printf("E\n");

    return NULL;
}

void *thread2(void *_arg) {

    printf("B\n");

    return NULL;
}

void *thread3(void *_arg) {

    printf("C\n");

    return NULL;
}

void *thread4(void *_arg) {

    printf("D\n");

    return NULL;
}

int main(int argc, char *argv[]) {

    // Crie TODAS as threads em um laço. Voce deve utilizar semaforos para sincronizacao.


    // Espere por TODAS as threads
    
    
    return 0;
}