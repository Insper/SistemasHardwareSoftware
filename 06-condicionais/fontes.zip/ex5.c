long ex5(long a, long b) {
    if (a > 0 && b < 1) {
        return a+5;
    }
    return b-2;
}
