#include <stdio.h>

void show_bytes(unsigned char *ptr, int n) {
    for (int i = 0; i < n; i++) {
        printf("%02x ", ptr[i]);  
    }
    printf("\n");
}                                                                                                                          
int main (int argc, char *argv[]) {
    short s = 0xBEEF;
    show_bytes((unsigned char *) &s, sizeof(s));

    int i = 0xABCDEF00;
    show_bytes((unsigned char*) &i, sizeof(i));

    long l = 0x0011223344AABBCCDD;
    show_bytes((unsigned char *) &l, sizeof(l));

    double d = -10;
    show_bytes((unsigned char *) &d, sizeof(d));

    return 0;
}
