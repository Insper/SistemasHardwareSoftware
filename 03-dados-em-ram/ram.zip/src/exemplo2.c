#include <stdio.h>

struct player {
    char name[20];
    long level;
    char icon_id;
    long score;
};

struct player one = {
    "nome nome nome",
    20,
    2,
    1012312312
};

struct player *ptr_struct = &one;

int main(int argc, char *argv[]) {
    printf("Sizeof(struct player) = %lu\n", sizeof(struct player));
    printf("--------\nname: %s\nlevel: %ld\nicon: %d\nscore: %ld\n", one.name, 
            one.level, one.icon_id, one.score);
    printf("---\nEndereços:\nname: %p\nlevel: %p\nicon: %p\nscore: %p\n", &one.name, 
            &one.level, &one.icon_id, &one.score);
    printf("----\nptr_struct: %p\n&one: %p, &one.name: %p\n", ptr_struct, &one, &one.name);
    return 0;
}
