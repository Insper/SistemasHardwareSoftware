#include <stdio.h>

void show_bytes(unsigned char *ptr, int n) {
    for (int i = 0; i < n; i++) {
        printf("%02x ", ptr[i]);
    }
    printf(" ");
}

int main (int argc, char *argv[]) {
    short arr[] = {1, 2, 3, 4, 5};
    show_bytes((unsigned char *) &arr, sizeof(short) * 5);
    printf("\n");
    return 0;
}
