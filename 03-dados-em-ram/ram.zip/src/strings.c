#include <stdio.h>
#include <string.h>

void show_bytes(unsigned char *ptr, int n) {
    for (int i = 0; i < n; i++) {
        printf("%02x ", ptr[i]);
    }
    printf("\n");
}

void show_chars(char *ptr, int n) {
    for (int i = 0; i < n; i++) {
        printf(" %c ", ptr[i]);
    }
    printf("\n");
}


char str1[] = "esta e a string!";
char str2[] = "12345";
 

int main (int argc, char *argv[]) {
    show_bytes((unsigned char *) str1, strlen(str1) + 1);
    show_chars(str1, strlen(str1)+1);

    printf("\n\n");
    show_bytes((unsigned char *) str2, strlen(str2) + 1);
    show_chars(str2, strlen(str2)+1);
    return 0;
}
