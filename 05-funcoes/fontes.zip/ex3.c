void ex3(int *a, int *b) {
    *a = (*b) * (*b);
}
