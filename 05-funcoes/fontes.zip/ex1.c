int ex1(int a, int b) {
    return a - b;
}
