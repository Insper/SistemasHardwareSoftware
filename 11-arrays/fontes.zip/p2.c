int func_que_recebe_array(int arr[3]) {
    long c = arr[0] + arr[1];
    return c < arr[2];
}
