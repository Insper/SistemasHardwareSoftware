int ex1(int a) {
    return a > 10;
}
