int ex3(long a, long b) {

    return a > b && b > 0;
}
