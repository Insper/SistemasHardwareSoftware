int ex2(unsigned long a, unsigned long b) {
    return a <= b;
}
