void ex2(int a, int *b) {
    *b = a+10;
}
